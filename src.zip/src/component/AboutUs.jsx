import React from 'react'

export default function AboutUs() {
    return (
        <div>
            <h2>AboutUs</h2>
        </div>
    )
}
